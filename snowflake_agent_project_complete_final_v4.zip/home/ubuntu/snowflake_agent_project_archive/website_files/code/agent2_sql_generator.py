# agent2_sql_generator.py

import json
import os
import random

class Agent2SQLGenerator:
    """
    Agent 2: Takes high-level use cases, understands Snowflake database structure via a Semantic Model,
    and generates specific, executable SQL queries for testing using Snowflake Cortex Analyst (conceptual).
    Updated to reflect P&C Insurance schema and generate simple to complex queries.
    """

    def __init__(self, semantic_model_path="/home/ubuntu/semantic_model_pc_insurance.yaml"):
        """
        Initializes the agent.
        semantic_model_path (str): Path to the conceptual P&C insurance semantic model YAML file.
        """
        self.semantic_model_path = semantic_model_path
        print(f"Agent 2 (SQL Generator) initialized. Using conceptual P&C semantic model: {self.semantic_model_path}")

    def _construct_cortex_agent_api_payload(self, use_case_text):
        """
        Constructs the payload for the conceptual Snowflake Cortex Agent API call.
        """
        payload = {
            "model": "llama3.1-70b",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": f"Based on our P&C Insurance database schema (defined in the semantic model 	\"{os.path.basename(self.semantic_model_path)}\"), generate a specific SQL query to test the following use case: {use_case_text}. Ensure the query is valid for Snowflake."
                        }
                    ]
                }
            ],
            "tools": [
                {
                    "tool_spec": {
                        "type": "cortex_analyst_text_to_sql",
                        "name": "insurance_database_analyzer"
                    }
                }
            ],
            "tool_resources": {
                "insurance_database_analyzer": {"semantic_model_file": f"@internal_stage/{os.path.basename(self.semantic_model_path)}"} # Conceptual stage path
            },
            "response_instruction": "Provide only the generated SQL query as a raw string. Do not include any explanations or markdown formatting."
        }
        return payload

    def _call_cortex_agent_api(self, payload):
        """
        (Conceptual) Simulates a call to the Snowflake Cortex Agent REST API for P&C Insurance.
        """
        use_case_in_payload = payload["messages"][0]["content"][0]["text"]
        print(f"\n--- Simulating Cortex Agent API Call (Agent 2 for P&C use case: 	\'{use_case_in_payload[:150]}...	\') ---")
        # print(f"Payload sent (conceptual):\n{json.dumps(payload, indent=2)}")

        simulated_sql_query = "-- Placeholder: No specific P&C SQL generated for this simulation."
        lc_use_case = use_case_in_payload.lower()

        # Simple Queries (Single Table, Basic Filters)
        if "list all active policies" in lc_use_case or "active policies for customer" in lc_use_case:
            simulated_sql_query = "SELECT PolicyID, CustomerID, PolicyType, EffectiveDate, ExpirationDate, Status FROM Policies WHERE Status = 	'Active	' LIMIT 10;"
        elif "find customers in state ca" in lc_use_case or "customers from california" in lc_use_case:
            simulated_sql_query = "SELECT CustomerID, FirstName, LastName, City, State FROM Customers WHERE State = 	'CA	' LIMIT 10;"
        elif "details of a specific claim" in lc_use_case or "claim by id" in lc_use_case:
            # Assuming a known ClaimID from sample data for a more realistic simple query
            sample_claim_id = "CLM00000001" # From sample_data_inserts_5_records.sql
            simulated_sql_query = f"SELECT ClaimID, PolicyID, DateOfLoss, Status, CauseOfLoss FROM Claims WHERE ClaimID = 	'{sample_claim_id}	';"
        elif "all users with role underwriter" in lc_use_case:
            simulated_sql_query = "SELECT UserID, UserName, Role FROM Users WHERE Role = 	'Underwriter	';"
        
        # Medium Complexity Queries (Joins, More Filters, Basic Aggregations)
        elif "policies and their primary customer details" in lc_use_case or "customer info for each policy" in lc_use_case:
            simulated_sql_query = (
                "SELECT p.PolicyID, p.PolicyType, p.Status, c.FirstName, c.LastName, c.EmailAddress \n"
                "FROM Policies p \n"
                "JOIN Customers c ON p.CustomerID = c.CustomerID \n"
                "LIMIT 10;"
            )
        elif "claims associated with a specific policy type" in lc_use_case or "claims for homeowners policies" in lc_use_case:
            simulated_sql_query = (
                "SELECT cl.ClaimID, cl.DateOfLoss, cl.Status, p.PolicyID, p.PolicyType \n"
                "FROM Claims cl \n"
                "JOIN Policies p ON cl.PolicyID = p.PolicyID \n"
                "WHERE p.PolicyType = 	'Homeowners	' \n"
                "LIMIT 10;"
            )
        elif "total premium for each policy type" in lc_use_case:
            simulated_sql_query = (
                "SELECT PolicyType, SUM(TotalPremium) AS TotalPremiumByType, COUNT(PolicyID) AS NumberOfPolicies \n"
                "FROM Policies \n"
                "GROUP BY PolicyType;"
            )
        elif "number of claims per policy" in lc_use_case:
            simulated_sql_query = (
                "SELECT PolicyID, COUNT(ClaimID) AS NumberOfClaims \n"
                "FROM Claims \n"
                "GROUP BY PolicyID \n"
                "ORDER BY NumberOfClaims DESC \n"
                "LIMIT 10;"
            )

        # Complex Queries (Multiple Joins, Subqueries, Window Functions, Complex Aggregations)
        elif "customers with multiple active policies and their total premium" in lc_use_case:
            simulated_sql_query = (
                "WITH CustomerPolicyCounts AS ( \n"
                "    SELECT CustomerID, COUNT(PolicyID) AS ActivePolicyCount, SUM(TotalPremium) AS TotalActivePremium \n"
                "    FROM Policies \n"
                "    WHERE Status = 	'Active	' \n"
                "    GROUP BY CustomerID \n"
                "    HAVING COUNT(PolicyID) > 1 \n"
                ") \n"
                "SELECT c.CustomerID, c.FirstName, c.LastName, cpc.ActivePolicyCount, cpc.TotalActivePremium \n"
                "FROM Customers c \n"
                "JOIN CustomerPolicyCounts cpc ON c.CustomerID = cpc.CustomerID \n"
                "ORDER BY cpc.TotalActivePremium DESC \n"
                "LIMIT 10;"
            )
        elif "average claim reserve amount by coverage type for recent claims" in lc_use_case:
            simulated_sql_query = (
                "SELECT pc.CoverageType, AVG(cr.CurrentReserveAmount) AS AverageReserveAmount \n"
                "FROM ClaimReserves cr \n"
                "JOIN Claims cl ON cr.ClaimID = cl.ClaimID \n"
                "JOIN PolicyCoverages pc ON cr.PolicyCoverageID = pc.PolicyCoverageID \n"
                "WHERE cl.DateReported >= DATEADD(year, -1, CURRENT_DATE()) \n"
                "GROUP BY pc.CoverageType \n"
                "ORDER BY AverageReserveAmount DESC;"
            )
        elif "policies expiring in the next 90 days with no renewal transaction" in lc_use_case:
            simulated_sql_query = (
                "SELECT p.PolicyID, p.CustomerID, p.ExpirationDate, p.PolicyType \n"
                "FROM Policies p \n"
                "LEFT JOIN PolicyTransactions pt ON p.PolicyID = pt.PolicyID AND pt.TransactionType = 	'Renewal	' \n"
                "WHERE p.Status = 	'Active	' \n"
                "  AND p.ExpirationDate BETWEEN CURRENT_DATE() AND DATEADD(day, 90, CURRENT_DATE()) \n"
                "  AND pt.PolicyTransactionID IS NULL \n"
                "LIMIT 10;"
            )
        elif "claim payment details along with claimant and policy information" in lc_use_case:
            simulated_sql_query = (
                "SELECT cp.ClaimPaymentID, cp.PaymentAmount, cp.PaymentDate, clm.ClaimantType, c.FirstName AS ClaimantFirstName, c.LastName AS ClaimantLastName, pol.PolicyType, cl.CauseOfLoss \n"
                "FROM ClaimPayments cp \n"
                "JOIN Claimants clm ON cp.ClaimantID = clm.ClaimantID \n"
                "JOIN Claims cl ON cp.ClaimID = cl.ClaimID \n"
                "JOIN Policies pol ON cl.PolicyID = pol.PolicyID \n"
                "LEFT JOIN Customers c ON clm.CustomerID = c.CustomerID \n"
                "ORDER BY cp.PaymentDate DESC \n"
                "LIMIT 10;"
            )
        else:
            # Fallback for unmapped use cases to ensure we get enough queries
            # More P&C specific fallbacks
            table_options = ["Policies", "Claims", "Customers", "PolicyCoverages"]
            column_options = ["Status", "PolicyType", "CauseOfLoss", "CustomerType", "CoverageType"]
            chosen_table = random.choice(table_options)
            chosen_column = random.choice(column_options)
            # Ensure the column is likely to exist in the chosen table for a slightly more plausible generic query
            if chosen_table == "Policies" and chosen_column not in ["Status", "PolicyType"]: chosen_column = "Status"
            if chosen_table == "Claims" and chosen_column not in ["Status", "CauseOfLoss"]: chosen_column = "Status"
            if chosen_table == "Customers" and chosen_column not in ["CustomerType", "State"]: chosen_column = "CustomerType"
            if chosen_table == "PolicyCoverages" and chosen_column not in ["CoverageType"]: chosen_column = "CoverageType"
            
            simulated_sql_query = f"SELECT * FROM {chosen_table} WHERE {chosen_column} IS NOT NULL ORDER BY RANDOM() LIMIT 5; -- Generic P&C fallback for: {use_case_in_payload[:30].replace(	"'	", "")}"

        print(f"Simulated SQL Query from Cortex Analyst (via Agent) for P&C:\n{simulated_sql_query}")
        print("--- End of Simulated Cortex Agent API Call ---\n")
        return simulated_sql_query

    def generate_sql_queries(self, high_level_use_cases):
        """
        Generates specific SQL queries from high-level use cases for P&C Insurance.
        """
        if not high_level_use_cases or not isinstance(high_level_use_cases, list):
            print("Error: No high-level use cases provided or format is incorrect.")
            return None

        sql_queries = []
        for use_case in high_level_use_cases:
            if not isinstance(use_case, str) or not use_case.strip():
                print(f"Warning: Skipping invalid use case: {use_case}")
                continue
            
            payload = self._construct_cortex_agent_api_payload(use_case)
            sql_query = self._call_cortex_agent_api(payload)
            
            if sql_query and "Placeholder: No specific P&C SQL generated" not in sql_query:
                # Avoid adding exact duplicates if the simulation logic produces them for similar use cases
                if sql_query not in sql_queries:
                    sql_queries.append(sql_query)
            else:
                print(f"Warning: Could not generate a specific SQL query for use case: {use_case}")

        # Ensure at least 10 queries if possible, using the fallback logic if needed
        idx = 0
        attempt_count = 0 # To prevent infinite loops if use cases are exhausted
        while len(sql_queries) < 10 and attempt_count < 2 * len(high_level_use_cases) + 5:
            use_case_for_fallback = high_level_use_cases[idx % len(high_level_use_cases)]
            # Generate a generic fallback query if specific ones failed or were insufficient
            payload = self._construct_cortex_agent_api_payload(f"Generic query for {use_case_for_fallback}") # Trigger fallback logic
            generic_query = self._call_cortex_agent_api(payload)
            if generic_query and "Placeholder: No specific P&C SQL generated" not in generic_query and generic_query not in sql_queries:
                 sql_queries.append(generic_query)
            idx += 1
            attempt_count +=1
        
        if len(sql_queries) == 0:
             print("Error: Failed to generate any SQL queries even with fallbacks.")
             return None
             
        return sql_queries[:10] # Return at most 10 as per original high-level plan

# --- Example Usage (Conceptual) ---
if __name__ == "__main__":
    print("Starting Agent 2 P&C Insurance SQL Generation example...")
    
    conceptual_semantic_model_file = "/home/ubuntu/semantic_model_pc_insurance.yaml"
    # Create a conceptual P&C semantic model file for the example
    # This would normally be a much more detailed file defining all tables, columns, relationships, and business context.
    with open(conceptual_semantic_model_file, "w") as f:
        f.write("""# Conceptual P&C Insurance Semantic Model (YAML)
version: 1
semantic_model:
  name: PC_Insurance_DB_SemanticModel
  description: Semantic model for the Property & Casualty Insurance database.
  tables:
    - name: Customers
      columns:
        - name: CustomerID
        - name: CustomerType
        - name: FirstName
        - name: State
    - name: Policies
      columns:
        - name: PolicyID
        - name: CustomerID
        - name: PolicyType
        - name: EffectiveDate
        - name: ExpirationDate
        - name: Status
        - name: TotalPremium
    - name: Claims
      columns:
        - name: ClaimID
        - name: PolicyID
        - name: DateOfLoss
        - name: DateReported
        - name: CauseOfLoss
        - name: Status
    - name: PolicyCoverages
      columns:
        - name: PolicyCoverageID
        - name: PolicyID
        - name: CoverageType
        - name: CoverageLimit
    - name: ClaimReserves
      columns:
        - name: ClaimReserveID
        - name: ClaimID
        - name: PolicyCoverageID
        - name: CurrentReserveAmount
    # ... Add all other P&C tables (InsuredAssets, PolicyTransactions, BillingSchedules, Claimants, ClaimPayments, etc.)
    # ... Define relationships and business context here for Cortex Analyst to use.
""")
    print(f"Created conceptual P&C semantic model at {conceptual_semantic_model_file}")

    agent2 = Agent2SQLGenerator(semantic_model_path=conceptual_semantic_model_file)

    # P&C specific use cases from Agent 1 (conceptual)
    sample_pc_use_cases = [
        "List all active policies for customers in California.",
        "Find details of a specific claim by its ID, including policy number and status.",
        "Show all users who have the role of 'Underwriter'.",
        "Retrieve all policies along with their primary customer's first name, last name, and email.",
        "List all claims for 'Homeowners' policies, showing claim ID, date of loss, and policy ID.",
        "Calculate the total premium amount for each policy type.",
        "Determine the number of claims associated with each policy, ordered by the highest number of claims.",
        "Identify customers who have more than one active policy and calculate their total active premium.",
        "Calculate the average claim reserve amount by coverage type for claims reported in the last year.",
        "Find active policies that are expiring in the next 90 days but do not have a 'Renewal' transaction logged.",
        "Show claim payment details including payment amount, date, claimant type, and policy type."
    ]

    print(f"\nInput P&C Use Cases for Agent 2:\n{json.dumps(sample_pc_use_cases, indent=2)}\n")

    generated_sql = agent2.generate_sql_queries(sample_pc_use_cases)

    if generated_sql:
        print("\nSuccessfully generated P&C SQL queries (up to 10 shown):")
        for i, sql in enumerate(generated_sql):
            print(f"\nQuery {i+1}:\n{sql}")
    else:
        print("\nFailed to generate P&C SQL queries.")

    print("\nAgent 2 P&C Insurance SQL Generation example finished.")


