-- sample_snowflake_setup.sql
-- This script provides DDL for creating sample tables and DML for inserting sample data
-- to be used with the Snowflake Multi-Agent SQL Test Case Generation System.

-- Create a new database and schema (optional, adjust if using existing)
-- CREATE DATABASE IF NOT EXISTS ECOMMERCE_DB;
-- CREATE SCHEMA IF NOT EXISTS ECOMMERCE_SCHEMA;
-- USE SCHEMA ECOMMERCE_DB.ECOMMERCE_SCHEMA;

-- Drop tables if they exist to ensure a clean setup
DROP TABLE IF EXISTS Order_Items;
DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Categories;
DROP TABLE IF EXISTS Customers;
DROP TABLE IF EXISTS Suppliers;
DROP TABLE IF EXISTS User_Profiles;
DROP TABLE IF EXISTS User_Roles;
DROP TABLE IF EXISTS Audit_Log;
DROP TABLE IF EXISTS Returns;
DROP TABLE IF EXISTS Financial_Data; -- Example for role-based access testing

-- Table Creation (DDL)

CREATE TABLE User_Roles (
    role_id INT PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL COMMENT 'e.g., customer, administrator, support_agent'
);

CREATE TABLE User_Profiles (
    user_id INT PRIMARY KEY AUTOINCREMENT START 1 INCREMENT 1,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    role_id INT NOT NULL,
    registration_date TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    last_login TIMESTAMP_NTZ,
    profile_status VARCHAR(20) DEFAULT 'active' COMMENT 'e.g., active, suspended, pending_verification',
    FOREIGN KEY (role_id) REFERENCES User_Roles(role_id)
);

CREATE TABLE Customers (
    customer_id INT PRIMARY KEY AUTOINCREMENT START 1001 INCREMENT 1,
    user_id INT UNIQUE, -- Link to User_Profiles if customers are also users
    customer_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(50),
    address_line1 VARCHAR(255),
    address_line2 VARCHAR(255),
    city VARCHAR(100),
    state_province VARCHAR(100),
    postal_code VARCHAR(20),
    country VARCHAR(100),
    registration_date TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    FOREIGN KEY (user_id) REFERENCES User_Profiles(user_id)
);

CREATE TABLE Categories (
    category_id INT PRIMARY KEY AUTOINCREMENT START 1 INCREMENT 1,
    category_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT
);

CREATE TABLE Suppliers (
    supplier_id INT PRIMARY KEY AUTOINCREMENT START 1 INCREMENT 1,
    supplier_name VARCHAR(255) UNIQUE NOT NULL,
    contact_person VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(50),
    address TEXT
);

CREATE TABLE Products (
    product_id INT PRIMARY KEY AUTOINCREMENT START 2001 INCREMENT 1,
    product_name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    category_id INT,
    supplier_id INT,
    stock_quantity INT DEFAULT 0 CHECK (stock_quantity >= 0),
    sku VARCHAR(100) UNIQUE,
    date_added TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    last_updated TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    FOREIGN KEY (category_id) REFERENCES Categories(category_id),
    FOREIGN KEY (supplier_id) REFERENCES Suppliers(supplier_id)
);

CREATE TABLE Orders (
    order_id INT PRIMARY KEY AUTOINCREMENT START 3001 INCREMENT 1,
    customer_id INT NOT NULL,
    order_date TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    order_status VARCHAR(50) NOT NULL COMMENT 'e.g., pending, processing, shipped, delivered, cancelled',
    shipping_address TEXT,
    billing_address TEXT,
    shipping_fee DECIMAL(10,2) DEFAULT 0.00,
    taxes DECIMAL(10,2) DEFAULT 0.00,
    order_total DECIMAL(12, 2) CHECK (order_total >= 0),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

CREATE TABLE Order_Items (
    order_item_id INT PRIMARY KEY AUTOINCREMENT START 4001 INCREMENT 1,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    price_at_purchase DECIMAL(10, 2) NOT NULL COMMENT 'Price of the product at the time of order',
    line_item_total DECIMAL(12, 2) GENERATED ALWAYS AS (quantity * price_at_purchase) STORED,
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

CREATE TABLE Returns (
    return_id INT PRIMARY KEY AUTOINCREMENT START 5001 INCREMENT 1,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    customer_id INT NOT NULL,
    quantity_returned INT NOT NULL CHECK (quantity_returned > 0),
    return_date TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    reason TEXT,
    return_status VARCHAR(50) COMMENT 'e.g., pending, approved, rejected, processed',
    processed_date TIMESTAMP_NTZ,
    refund_amount DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

CREATE TABLE Audit_Log (
    log_id INT PRIMARY KEY AUTOINCREMENT START 6001 INCREMENT 1,
    user_id INT,
    action_performed VARCHAR(255) NOT NULL,
    table_affected VARCHAR(100),
    record_id_affected VARCHAR(100),
    log_timestamp TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    details TEXT,
    FOREIGN KEY (user_id) REFERENCES User_Profiles(user_id)
);

CREATE TABLE Financial_Data (
    transaction_id INT PRIMARY KEY AUTOINCREMENT START 7001 INCREMENT 1,
    transaction_date DATE NOT NULL,
    description VARCHAR(255),
    amount DECIMAL(15,2) NOT NULL,
    transaction_type VARCHAR(50) COMMENT 'e.g., revenue, expense, tax_payment'
);

-- Sample Data Insertion (DML)

INSERT INTO User_Roles (role_id, role_name) VALUES
(1, 'customer'),
(2, 'administrator'),
(3, 'support_agent');

INSERT INTO User_Profiles (user_id, username, email, hashed_password, full_name, role_id, registration_date, profile_status)
VALUES
(1, 'alice_w', 'alice.wonderland@example.com', 'hashed_pw_alice', 'Alice Wonderland', 1, '2023-01-10 10:00:00', 'active'),
(2, 'bob_b', 'bob.builder@example.com', 'hashed_pw_bob', 'Bob The Builder', 1, '2023-01-15 11:00:00', 'active'),
(3, 'admin_user', 'admin@example.com', 'hashed_pw_admin', 'Admin User', 2, '2023-01-01 09:00:00', 'active'),
(4, 'support_sam', 'sam.support@example.com', 'hashed_pw_sam', 'Sam Support', 3, '2023-02-01 14:00:00', 'active'),
(5, 'charlie_c', 'charlie.chaplin@example.com', 'hashed_pw_charlie', 'Charlie Chaplin', 1, '2023-03-01 12:00:00', 'pending_verification');

INSERT INTO Customers (customer_id, user_id, customer_name, email, phone, address_line1, city, country, registration_date)
VALUES
(1001, 1, 'Alice Wonderland', 'alice.wonderland@example.com', '555-0101', '123 Rabbit Hole Ln', 'Wonderland', 'Fictionland', '2023-01-10 10:00:00'),
(1002, 2, 'Bob The Builder', 'bob.builder@example.com', '555-0102', '456 Construction Ave', 'Builderville', 'Toontown', '2023-01-15 11:00:00'),
(1003, 5, 'Charlie Chaplin', 'charlie.chaplin@example.com', '555-0103', '789 Silent Film St', 'Hollywood', 'USA', '2023-03-01 12:00:00');

INSERT INTO Categories (category_id, category_name, description)
VALUES
(1, 'Electronics', 'Gadgets, computers, and accessories'),
(2, 'Books', 'Fiction, non-fiction, educational books'),
(3, 'Home Goods', 'Items for home and kitchen');

INSERT INTO Suppliers (supplier_id, supplier_name, contact_person, email, phone)
VALUES
(1, 'Techtronics Inc.', 'Sarah Connor', 'sales@techtronics.com', '555-0201'),
(2, 'Global Books Ltd.', 'John Doe', 'orders@globalbooks.com', '555-0202'),
(3, 'Home Comforts Co.', 'Jane Smith', 'info@homecomforts.co', '555-0203');

INSERT INTO Products (product_id, product_name, description, price, category_id, supplier_id, stock_quantity, sku)
VALUES
(2001, 'Laptop Pro X1', 'High-performance laptop for professionals', 1299.99, 1, 1, 50, 'LPX1-001'),
(2002, 'Wireless Ergonomic Mouse', 'Comfortable mouse for long hours', 49.99, 1, 1, 200, 'WEM-002'),
(2003, 'The Great Novel', 'A best-selling fiction book', 19.99, 2, 2, 150, 'TGN-003'),
(2004, 'Smart Coffee Maker', 'Wi-Fi enabled coffee maker', 89.99, 3, 3, 75, 'SCM-004'),
(2005, 'Quantum Computing Explained', 'An advanced physics textbook', 75.50, 2, 2, 30, 'QCE-005');

INSERT INTO Orders (order_id, customer_id, order_date, order_status, shipping_address, order_total)
VALUES
(3001, 1001, '2023-02-15 14:30:00', 'delivered', '123 Rabbit Hole Ln, Wonderland', 1349.98),
(3002, 1002, '2023-03-01 09:15:00', 'shipped', '456 Construction Ave, Builderville', 109.98),
(3003, 1001, '2023-03-10 17:00:00', 'processing', '123 Rabbit Hole Ln, Wonderland', 75.50),
(3004, 1003, '2023-04-01 10:00:00', 'pending', '789 Silent Film St, Hollywood', 19.99);

INSERT INTO Order_Items (order_id, product_id, quantity, price_at_purchase)
VALUES
(3001, 2001, 1, 1299.99),
(3001, 2002, 1, 49.99),
(3002, 2002, 1, 49.99),
(3002, 2004, 1, 89.99), -- Error in original data, should be 1 * 89.99 = 89.99, total 139.98. Correcting order total for 3002.
(3003, 2005, 1, 75.50),
(3004, 2003, 1, 19.99);

-- Correcting Order 3002 total based on items
UPDATE Orders SET order_total = (SELECT SUM(oi.line_item_total) FROM Order_Items oi WHERE oi.order_id = 3002) WHERE order_id = 3002;

INSERT INTO Returns (order_id, product_id, customer_id, quantity_returned, return_date, reason, return_status, processed_date, refund_amount)
VALUES
(3002, 2002, 1002, 1, '2023-03-10 10:00:00', 'Defective item', 'approved', '2023-03-11 15:00:00', 49.99);

INSERT INTO Audit_Log (user_id, action_performed, table_affected, record_id_affected, details)
VALUES
(3, 'User Login', 'User_Profiles', '3', 'Admin user logged in successfully'),
(1, 'Place Order', 'Orders', '3001', 'Alice placed order 3001'),
(2, 'Product Stock Update', 'Products', '2002', 'Stock for Wireless Ergonomic Mouse updated after return.');

INSERT INTO Financial_Data (transaction_date, description, amount, transaction_type)
VALUES
('2023-02-15', 'Sale from Order 3001', 1349.98, 'revenue'),
('2023-03-01', 'Sale from Order 3002', (SELECT order_total FROM Orders WHERE order_id = 3002), 'revenue'),
('2023-03-11', 'Refund for Return on Order 3002', -49.99, 'refund');


-- Verification Queries (Optional)
SELECT 'User_Roles' AS table_name, COUNT(*) AS record_count FROM User_Roles
UNION ALL
SELECT 'User_Profiles', COUNT(*) FROM User_Profiles
UNION ALL
SELECT 'Customers', COUNT(*) FROM Customers
UNION ALL
SELECT 'Categories', COUNT(*) FROM Categories
UNION ALL
SELECT 'Suppliers', COUNT(*) FROM Suppliers
UNION ALL
SELECT 'Products', COUNT(*) FROM Products
UNION ALL
SELECT 'Orders', COUNT(*) FROM Orders
UNION ALL
SELECT 'Order_Items', COUNT(*) FROM Order_Items
UNION ALL
SELECT 'Returns', COUNT(*) FROM Returns
UNION ALL
SELECT 'Audit_Log', COUNT(*) FROM Audit_Log
UNION ALL
SELECT 'Financial_Data', COUNT(*) FROM Financial_Data;

SELECT * FROM Customers LIMIT 5;
SELECT * FROM Products ORDER BY price DESC LIMIT 5;
SELECT o.order_id, c.customer_name, o.order_date, o.order_total, o.order_status
FROM Orders o
JOIN Customers c ON o.customer_id = c.customer_id
ORDER BY o.order_date DESC
LIMIT 5;

PRINT 'Sample data setup complete.';


