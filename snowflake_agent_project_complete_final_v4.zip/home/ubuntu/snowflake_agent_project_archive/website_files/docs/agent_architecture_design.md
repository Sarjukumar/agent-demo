# Snowflake Multi-Agent System for SQL Test Case Generation and Execution

## 1. Architecture Overview

This document outlines the architecture for a multi-agent system designed to take a requirements document, generate SQL test use cases for a Snowflake database, execute these use cases, and present the results. The system leverages Snowflake Cortex GenAI capabilities, Python, and Streamlit, and is designed with compatibility for the Snowflake Cortex AI platform in mind. It comprises three core agents, a main orchestrator, and a Streamlit user interface.

**Core Principles:**

*   **Modularity:** Each agent has a distinct responsibility.
*   **Snowflake Native:** Prioritizes the use of Snowflake Cortex features (LLM Functions, Cortex Analyst, Llama models) where applicable.
*   **Metadata-Driven:** Agent 2 heavily relies on a Snowflake Semantic Model for accurate SQL generation.
*   **User-Friendly Interface:** Streamlit provides an accessible way to interact with the system.

## 2. Component Breakdown and Diagram

```mermaid
graph TD
    A[Streamlit UI] --> B(Main Orchestrator);
    B --> C{Agent 1: Requirements Analyzer};
    C -- Requirements Doc --> C;
    C -- High-level Use Cases --> B;
    B --> D{Agent 2: SQL Generator};
    D -- High-level Use Cases & Semantic Model --> D;
    D -- Generated SQL Queries --> B;
    B --> E{Agent 3: SQL Executor};
    E -- SQL Queries --> E;
    E -- Query Results (10 records/query) --> B;
    B -- All Outputs --> A;

    C --> F[Snowflake Cortex LLM Function (Llama)];
    D --> G[Snowflake Cortex Analyst (via Agent API / Semantic Model)];
    E --> H[Snowflake Database (via Python Connector)];

    subgraph User Interface
        A
    end

    subgraph Core Logic
        B
        C
        D
        E
    end

    subgraph Snowflake Platform
        F
        G
        H
        I[Semantic Model .yaml]
    end

    D -.-> I;  // Agent 2 uses Semantic Model
```

*(The above is a Mermaid syntax diagram. If rendering is not available, please interpret it as a flow diagram based on the descriptions below.)*

**Component Descriptions:**

### 2.1. Streamlit UI

*   **Purpose:** Provides the primary user interface for the system.
*   **Functionality:**
    *   Allows users to upload the textual requirements document.
    *   Provides a button or control to initiate the agent workflow.
    *   Displays the outputs from each agent: high-level use cases, generated SQL queries, and the execution results (limited to 10 records per query).
    *   May also display this architecture diagram and explanations.
*   **Technology:** Streamlit, Python.

### 2.2. Main Orchestrator

*   **Purpose:** Manages the overall workflow, data flow, and communication between the three specialized agents.
*   **Functionality:**
    *   Receives the requirements document from the Streamlit UI.
    *   Invokes Agent 1, passing the requirements document.
    *   Receives high-level use cases from Agent 1.
    *   Invokes Agent 2, passing the high-level use cases and ensuring Agent 2 has access to the necessary Semantic Model configuration.
    *   Receives generated SQL queries from Agent 2.
    *   Invokes Agent 3, passing the SQL queries.
    *   Receives formatted query execution results from Agent 3.
    *   Passes all intermediate and final results back to the Streamlit UI for display.
*   **Technology:** Python.

### 2.3. Agent 1: Requirements Analyzer & Initial Use Case Generator

*   **Purpose:** To process the input requirements document and extract high-level testing objectives or use cases.
*   **Inputs:** Requirements document (text format).
*   **Processing Logic:**
    1.  The requirements document is provided as a prompt to a Snowflake Cortex LLM function (e.g., `SNOWFLAKE.CORTEX.COMPLETE` using a Llama model like `llama3.1-70b`).
    2.  The prompt will instruct the LLM to analyze the text, identify key functionalities, data entities, and relationships that need testing.
    3.  The LLM will generate a list of natural language, high-level use cases or questions that describe *what* to test, rather than *how* (i.e., not SQL yet).
*   **Outputs:** A list of high-level use cases/questions (e.g., "Verify calculations for monthly sales totals per region," "Check data integrity for customer addresses").
*   **Snowflake Interaction:** Uses Snowflake Cortex LLM Functions.
*   **Technology:** Python, Snowflake SQL (for calling Cortex functions).

### 2.4. Agent 2: Metadata-Driven Use Case Refiner & SQL Generator

*   **Purpose:** To take high-level use cases, understand the Snowflake database structure via its metadata (Semantic Model), and generate specific, executable SQL queries for testing.
*   **Inputs:**
    *   List of high-level use cases/questions from Agent 1.
    *   Configuration pointing to a **Semantic Model** (YAML file). This model defines the target Snowflake database schema, tables, columns, data types, relationships (PKs, FKs), and business context.
*   **Processing Logic:**
    1.  For each high-level use case, Agent 2 formulates a more specific natural language query suitable for Snowflake Cortex Analyst.
    2.  It interacts with **Snowflake Cortex Analyst**. This interaction will likely be through the Cortex Agent API (`/api/v2/cortex/agent:run`), specifying `cortex_analyst_text_to_sql` as a tool and providing the path/reference to the semantic model file.
    3.  Cortex Analyst, guided by the semantic model, translates the natural language query into an appropriate SQL query.
    4.  The agent aims to generate at least 10 distinct SQL queries covering different aspects of the database as suggested by the use cases and illuminated by the semantic model.
*   **Outputs:** A list of 10+ SQL queries.
*   **Snowflake Interaction:** Uses Snowflake Cortex Analyst (via Cortex Agent API) and relies heavily on a pre-defined Semantic Model.
*   **Technology:** Python, REST API calls to Cortex Agent API.

### 2.5. Agent 3: SQL Executor & Results Formatter

*   **Purpose:** To execute the generated SQL queries against the Snowflake database and format the results.
*   **Inputs:** List of SQL queries from Agent 2.
*   **Processing Logic:**
    1.  Establishes a connection to the target Snowflake database using the Snowflake Connector for Python.
    2.  For each SQL query in the list:
        a.  Executes the query against the database.
        b.  Fetches the results.
        c.  Formats the results, ensuring that a maximum of 10 records are returned for each query as per requirements.
*   **Outputs:** A structured collection of results, with each SQL query mapped to its (potentially truncated) output.
*   **Snowflake Interaction:** Direct database connection and SQL execution using Snowflake Connector for Python.
*   **Technology:** Python, `snowflake-connector-python` library.

### 2.6. Snowflake Components

*   **Snowflake Cortex LLM Function (e.g., Llama model):** Used by Agent 1 for natural language understanding and generation from the requirements document.
*   **Snowflake Cortex Analyst:** Used by Agent 2 for text-to-SQL generation, guided by the semantic model.
*   **Semantic Model (.yaml file):** A critical input for Agent 2 / Cortex Analyst. This file must be meticulously crafted to describe the database schema, relationships, and business context to enable accurate SQL generation. *The creation of a sample semantic model will be part of the project deliverables.*
*   **Snowflake Database:** The target database where Agent 3 executes SQL queries and retrieves data. *Sample DDL/DML for tables and data will be provided as part of the project deliverables to make the system testable.*

## 3. Data Flow

1.  **User** uploads requirements.txt via **Streamlit UI**.
2.  **Streamlit UI** sends requirements.txt to **Main Orchestrator**.
3.  **Main Orchestrator** passes requirements.txt to **Agent 1**.
4.  **Agent 1** uses **Snowflake Cortex LLM Function** to produce high-level use cases.
5.  **Agent 1** returns high-level use cases to **Main Orchestrator**.
6.  **Main Orchestrator** passes high-level use cases to **Agent 2** (along with Semantic Model info).
7.  **Agent 2** uses **Snowflake Cortex Analyst** (with Semantic Model) to generate SQL queries.
8.  **Agent 2** returns SQL queries to **Main Orchestrator**.
9.  **Main Orchestrator** passes SQL queries to **Agent 3**.
10. **Agent 3** uses **Snowflake Connector** to execute SQL on **Snowflake DB** and retrieve results.
11. **Agent 3** returns formatted results (10 records/query) to **Main Orchestrator**.
12. **Main Orchestrator** sends all outputs (use cases, SQL, results) to **Streamlit UI** for display.

## 4. Future Considerations / Advanced Features (Optional)

*   **Feedback Loop:** Incorporating user feedback on generated SQL or use cases to refine future runs.
*   **Automated Semantic Model Generation/Suggestion:** Exploring if parts of the semantic model could be bootstrapped from `INFORMATION_SCHEMA`.
*   **More Complex Orchestration:** Using a more formal state management or workflow engine if the agent interactions become significantly more complex.
*   **Direct Cortex Agent Orchestration:** As Cortex Agents mature, explore using a single, more powerful Cortex Agent to orchestrate these sub-tasks if the platform allows for such custom multi-step Python logic execution within its framework directly.

