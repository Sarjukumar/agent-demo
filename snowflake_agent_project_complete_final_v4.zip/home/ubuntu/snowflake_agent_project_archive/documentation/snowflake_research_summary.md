# Snowflake GenAI and Cortex AI Research Summary

This document summarizes key findings from the official Snowflake documentation relevant to building a multi-agent system for generating and testing Snowflake SQL use cases.

## 1. Snowflake Cortex Agents

Cortex Agents are designed to orchestrate tasks across structured and unstructured data sources to deliver insights. They operate based on a four-step workflow:

*   **Planning**: Agents parse requests, explore options to disambiguate queries, split tasks into subtasks, and route requests to appropriate tools (Cortex Analyst or Cortex Search).
*   **Tool Use**: Agents utilize tools to retrieve and process data. Cortex Analyst generates SQL for structured data, while Cortex Search extracts insights from unstructured sources.
*   **Reflection**: After each tool use, the agent evaluates results to determine subsequent actions, such as asking for clarification, iterating, or generating a final response.
*   **Monitor and Iterate**: Post-deployment, performance can be tracked and behaviors refined. TruLens can be used for monitoring agent interactions.

**Key Features & Usage:**
*   **API**: Cortex Agents are accessed via a REST API endpoint: `/api/v2/cortex/agent:run`.
*   **Authentication**: Requires JWT tokens generated via key-pair authentication.
*   **Input**: The API call includes the chosen model, user messages (content), tool specifications, and tool resources.
*   **Output**: Responses are streamed incrementally to the client.
*   **Supported LLMs for Response Generation**: `llama3.1-70b`, `llama3.3-70b`, `mistral-large2`, `claude-3-5-sonnet`. The user specifically requested a Llama LLM, and compatible versions are available. The chosen model is used for generating the agent's response, not for the core orchestration logic itself.
*   **Tool Specification**: The API call defines the tools the agent can use, such as `cortex_search` and `cortex_analyst_text_to_sql`.
*   **Tool Resources**: Specifies the actual instances of these tools, e.g., the name of the Cortex Search Service or the path to the Cortex Analyst semantic model file.

## 2. Cortex Analyst

Cortex Analyst is a tool used by Cortex Agents to interact with structured data. Its primary function is to generate SQL queries from natural language prompts.

*   **Semantic Model**: Cortex Analyst relies on a **Semantic Model**, which is a YAML file defining the database schema, tables, columns, relationships, and relevant business context. This model is crucial for enabling the LLM to understand the data structure and generate accurate SQL.
*   **Functionality**: It translates natural language questions about structured data into executable SQL queries.

## 3. Cortex Search

Cortex Search is a tool for extracting insights from unstructured data sources. While not the primary focus for SQL generation, it could be used by Agent 1 if the requirements document itself is treated as an unstructured source to be queried for key information before generating use cases.

*   **Setup**: Requires creating a Cortex Search Service.

## 4. Metadata Access for SQL Generation

Understanding table relationships and database metadata is critical for Agent 2. This is primarily achieved through the **Semantic Model** provided to Cortex Analyst. The semantic model must accurately describe:
*   Tables and their columns (with data types and descriptions).
*   Primary and foreign key relationships between tables.
*   Joins, views, and any other relevant database constructs.
*   Business definitions and context for fields and tables.

## 5. SQL Execution

The documentation for Cortex Analyst focuses on its role in *generating* SQL. The execution of this SQL and retrieval of results would typically be handled by standard Snowflake connectors (e.g., Snowflake Connector for Python) within the agent or application logic, after the SQL is returned by Cortex Analyst.

## 6. Agent Orchestration and Design Considerations for the Project

*   **Agent 1 (Requirements Processing)**:
    *   Will take a requirements document as input.
    *   Can use a Cortex LLM Function (e.g., `COMPLETE` with a Llama model) to parse the document, extract key entities, and generate an initial set of natural language questions or high-level use cases.
*   **Agent 2 (Use Case & SQL Generation from Metadata)**:
    *   Will use Cortex Analyst as its primary tool.
    *   Requires a well-defined Semantic Model for the target Snowflake database.
    *   Will take high-level use cases/questions (possibly from Agent 1 or predefined) and use Cortex Analyst to generate 10+ specific SQL queries for testing.
    *   The prompts to Cortex Analyst will be critical for generating relevant and diverse SQL queries.
*   **Agent 3 (SQL Execution & Reporting)**:
    *   Will take SQL queries from Agent 2.
    *   Will use the Snowflake Connector for Python to connect to the database, execute each query, and fetch results.
    *   Will format the output, limiting it to 10 records per query.

*   **Overall Orchestration**: While Cortex Agents provide a framework, the specific flow and interaction between these three custom-defined Python agents might be managed by a main Python script or a simple state machine, which then calls the Cortex Agent API for specific LLM-driven tasks where appropriate (e.g., Agent 1 using LLM for text processing, Agent 2 using Cortex Analyst tool via the Agent API).
*   **Streamlit Interface**: Will provide the UI for uploading requirements, initiating the process, and displaying outputs (use cases, SQL, query results, architecture diagram).

## 7. Snowflake Cortex AI Platform Compatibility

The solution will be designed to:
*   Utilize Cortex LLM functions (e.g., with Llama models).
*   Leverage Cortex Analyst for text-to-SQL, driven by a semantic model.
*   Conceptually align with the Cortex Agents framework for tool use and planning where applicable, even if the overarching orchestration of the three *project-specific* agents is custom Python code.
*   Use the Snowflake Connector for Python for direct database interactions (SQL execution, metadata queries if needed beyond the semantic model).

This research provides a solid foundation for designing the agent architecture and proceeding with development.
